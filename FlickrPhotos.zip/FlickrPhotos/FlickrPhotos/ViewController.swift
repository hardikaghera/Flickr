//
//  ViewController.swift
//  FlickrPhotos
//
//  Created by Hardik Aghera on 18/05/18.
//  Copyright © 2018 Hardik Aghera. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    @IBOutlet weak var collectionView: UICollectionView!
    let reuseIdentifier = "cell"
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func highlightCell(indexPath : NSIndexPath, flag: Bool) {
        
        let cell = collectionView.cellForItem(at: indexPath as IndexPath)
        
        if flag {
          //  cell?.contentView.backgroundColor = UIColor.magenta
            cell?.layer.borderColor = UIColor.blue.cgColor
            cell?.layer.borderWidth = 4.0
        } else {
            cell?.layer.borderColor = UIColor.clear.cgColor
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! PhotosCollectionViewCell
        cell.photos.image = UIImage(named:"picture")
        return cell

    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        highlightCell(indexPath: indexPath as NSIndexPath, flag: true)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        highlightCell(indexPath: indexPath as NSIndexPath, flag: false)
    }
    
    
    
    
}



//
//  PhotosCollectionViewCell.swift
//  FlickrPhotos
//
//  Created by Hardik Aghera on 18/05/18.
//  Copyright © 2018 Hardik Aghera. All rights reserved.
//

import UIKit

class PhotosCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photos: UIImageView!
    
}
